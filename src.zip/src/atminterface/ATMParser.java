package atminterface;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.util.Date;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class ATMParser {
    
    private String response = "";
    
    public String hexToBinary(String hex1, String hex2) {
        
        long    number1, number2;
        String  binary, binary1, binary2;
        
        number1 = new java.math.BigInteger(hex1, 16).longValue();
        binary1 = Long.toBinaryString(number1);
        String bin1 = String.format("%64s", binary1).replace(" ", "0");
        
	number2 = new java.math.BigInteger(hex2, 16).longValue();
        binary2 = Long.toBinaryString(number2);
        String bin2 = String.format("%64s", binary2).replace(" ", "0");
        
        binary = new StringBuilder().append(bin1).append(bin2).toString();
        
        return  binary;
    }
    
    public String returnToClient(ConcurrentHashMap outputParams,String output){
        
        String  msg = "";
        String  action = (String)outputParams.get("action");
        Gson    gson = new Gson();
        Type    type = new TypeToken<Map<String, String>>(){}.getType();
             
        Map<String, String> myMap = gson.fromJson(output, type);
        
        msg = new StringBuilder().append(myMap.get("partOne")).append(myMap.get("response")).append(myMap.get("partTwo")).toString();
        System.out.println(myMap);
        
        /*
        if(action.equals("inquiry")){
            if(myMap.get("error").equals("")){
                if(myMap.get("isReversal").equals(""))
                    msg = "INQ " + myMap.get("dateAndTime") + " | IP " + myMap.get("sourceIp") + " | Port " + myMap.get("sourcePort") + " | Account Number: " + myMap.get("acctNo") + ", Closing Balance: " + myMap.get("closingBalAmt") + ", Available Balance: " + myMap.get("availableBalAmt");
                else if(myMap.get("isReversal").equals("REVERSED"))
                    msg = "INQ " + myMap.get("dateAndTime") + " | IP " + myMap.get("sourceIp") + " | Port " + myMap.get("sourcePort") + " | Transaction for Account Number " + myMap.get("acctNo") + " " + myMap.get("isReversal");
            }
            else
                msg = "INQ " + myMap.get("dateAndTime") + " | IP " + myMap.get("sourceIp") + " | Port " + myMap.get("sourcePort") + " | " + myMap.get("error");
        }
        else if(action.equals("withdrawal")){
            if(myMap.get("error").equals("")){
                if(myMap.get("isReversal").equals(""))
                    msg = "WDL " + myMap.get("dateAndTime") + " | IP " + myMap.get("sourceIp") + " | Port " + myMap.get("sourcePort") + " | Account Number: " + myMap.get("acctNo") + ", Amount Withdrawn: " + myMap.get("withdrawnAmt") + ", Available Balance: " + myMap.get("availableBalAmt");
                else if(myMap.get("isReversal").equals("REVERSED"))
                    msg = "WDL " + myMap.get("dateAndTime") + " | IP " + myMap.get("sourceIp") + " | Port " + myMap.get("sourcePort") + " | Transaction for Account Number " + myMap.get("acctNo") + " " + myMap.get("isReversal");
            }
            else
                msg = "WDL " + myMap.get("dateAndTime") + " | IP " + myMap.get("sourceIp") + " | Port " + myMap.get("sourcePort") + " | " + myMap.get("error");
        }
        else if(action.equals("intraFT")){
            if(myMap.get("error").equals("")){
                if(myMap.get("isReversal").equals(""))
                    msg = "INTRA TRN " + myMap.get("dateAndTime") + " | IP " + myMap.get("sourceIp") + " | Port " + myMap.get("sourcePort") + " | Primary Account Number: " + myMap.get("acctNo") + ", Fund Transfer Account Number: " + myMap.get("toAcct") + ", Amount Transferred: " + myMap.get("transferredAmt") + ", Primary Account Balance: " + myMap.get("availableBalAmt1") + ", Fund Transfer Account Balance: " + myMap.get("availableBalAmt2");
                else if(myMap.get("isReversal").equals("REVERSED"))
                    msg = "INTRA TRN " + myMap.get("dateAndTime") + " | IP " + myMap.get("sourceIp") + " | Port " + myMap.get("sourcePort") + " | Transaction for Account Number " + myMap.get("acctNo") + " " + myMap.get("isReversal");
            }
            else
                msg = "INTRA TRN " + myMap.get("dateAndTime") + " | IP " + myMap.get("sourceIp") + " | Port " + myMap.get("sourcePort") + " | " + myMap.get("error");
        }
        else if(action.equals("interFT")){
            if(myMap.get("error").equals("")){
                if(myMap.get("isReversal").equals(""))
                    msg = "INTER TRN " + myMap.get("dateAndTime") + " | IP " + myMap.get("sourceIp") + " | Port " + myMap.get("sourcePort") + " | Primary Account Number: " + myMap.get("acctNo") + ", Fund Transfer Account Number: " + myMap.get("toAcct") + ", Amount Transferred: " + myMap.get("transferredAmt") + ", Primary Account Balance: " + myMap.get("availableBalAmt1") + ", Fund Transfer Account Balance: " + myMap.get("availableBalAmt2");
                else if(myMap.get("isReversal").equals("REVERSED"))
                    msg = "INTER TRN " + myMap.get("dateAndTime") + " | IP " + myMap.get("sourceIp") + " | Port " + myMap.get("sourcePort") + " | Transaction for Account Number " + myMap.get("acctNo") + " " + myMap.get("isReversal");
            }
            else
                msg = "INTER TRN " + myMap.get("dateAndTime") + " | IP " + myMap.get("sourceIp") + " | Port " + myMap.get("sourcePort") + " | " + myMap.get("error");
        }
        else if(action.equals("billsPayment")){
            if(myMap.get("error").equals("")){
                if(myMap.get("isReversal").equals(""))
                    msg = "PAY " + myMap.get("dateAndTime") + " | IP " + myMap.get("sourceIp") + " | Port " + myMap.get("sourcePort") + " | Account Number: " + myMap.get("acctNo") + ", Amount Paid: " + myMap.get("paidAmt") + ", Available Balance: " + myMap.get("availableBalAmt");
                else if(myMap.get("isReversal").equals("REVERSED"))
                    msg = "PAY " + myMap.get("dateAndTime") + " | IP " + myMap.get("sourceIp") + " | Port " + myMap.get("sourcePort") + " | Transaction for Account Number " + myMap.get("acctNo") + " " + myMap.get("isReversal");
            }
            else
                msg = "PAY " + myMap.get("dateAndTime") + " | IP " + myMap.get("sourceIp") + " | Port " + myMap.get("sourcePort") + " | " + myMap.get("error");
        }
        else if(action.equals("checkbookReq")){
            msg = "CHKREQ " + myMap.get("dateAndTime") + " | IP " + myMap.get("sourceIp") + " | Port " + myMap.get("sourcePort") + " | " + myMap.get("error");
        }
        else if(action.equals("statementReq")){
            msg = "STAT " + myMap.get("dateAndTime") + " | IP " + myMap.get("sourceIp") + " | Port " + myMap.get("sourcePort") + " | " + myMap.get("error");
        } */
        
        return  msg;
    }
    
    public ConcurrentHashMap generateResponse(String s){
        
        ConcurrentHashMap<String, String> ret = new ConcurrentHashMap<String, String>();
        
        int         a = 0, b = 0, c = 0, d = 0, e = 0, f = 0, g = 0, h = 0, m = 0;
        int         iMsgLength = 0;
        int         responseLength = 0;
        int         header = 0;
        int         tempz = 0;
        char[]      sa = s.toCharArray();
        char[]      msgLength = new char[4];        // First four digits correspond to message length
        char[]      request = new char[4];          // Next four digits correspond to whether the message is a request or response
        char[]      bitmap1 = new char[16];         // Next 16 digits correspond to half of the (hexadecimal) bitmap
        char[]      bitmap2 = new char[16];         // Next 16 digits correspond to the other half of the (hexadecimal) bitmap
        char[]      binBitmap = new char[128];
        char[]      resBinBitmap = {'0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '-', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0'};
        char[]      actualMsg = new char[sa.length - 4];
        char[][]    eVal = new char[57][120];       // Element values
        char[][]    eValRes = new char[57][120];       // Element values
        char[]      acctNoFormat = {'n', 'n', 'n', '-', 'n', 'n', 'n', '-', 'n', 'n', 'n', 'n', 'n', '-', 'n'};
        char[]      acctNo2Format = {'n', 'n', 'n', '-', 'n', 'n', 'n', '-', 'n', 'n', 'n', 'n', 'n', '-', 'n'};
        String      resBitmap1 = "";
        String      resBitmap2 = "";
        String      strBinBitmap = "";
        String      sagot = "";
        // ################ ARRAYS FOR THE BITMAP TABLE ###############
        int[]       id = {2, 3, 4, 5, 7, 8, 9, 10, 11, 12, 13, 14, 15, 17, 18, 19, 22, 24, 25, 28, 29, 30, 31, 32, 33, 34, 35, 37, 38, 39, 41, 42, 43, 48, 49, 50, 51, 52, 54, 59, 60, 62, 70, 90, 95, 100, 102, 103, 114, 115, 116, 117, 118, 120, 121, 122, 127}; 
        boolean[]   isVar = {true, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true, true, false, true, false, false, false, false, false, false, true, false, false, false, false, false, false, true, true, true, false, false, true, true, true, true, true, true, true, true, true, true, true, true};
        int[]       fLen = {2, 6, 12, 12, 10, 8, 8, 8, 6, 6, 4, 4, 4, 4, 4, 3, 3, 3, 2, 8, 8, 8, 8, 2, 2, 28, 2, 12, 6, 2, 8, 15, 40, 3, 3, 3, 3, 16, 120, 3, 3, 3, 4, 42, 42, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3};
        boolean[]   isToRespond = {true, true, true, false, true, false, false, false, true, true, true, true, false, false, true, false, true, true, true, false, false, false, false, false, false, false, false, true, false, true, true, false, true, false, true, true, false, false, true, false, false, true, false, false, false, false, true, false, false, false, false, false, false, false, false, false, false};
        //boolean[]   isInRequest = {true, true, true, false, true, false, false, false, true, true, true, false, false, false, false, false, false, false, false, false, false, false, false, true, false, false, false, true, false, true, true, false, false, false, true, false, false, false, true, false, false, false, false, false, false, true, false, false, false, false, false, false, false, false, false, false};
        boolean[]   isInResponse = {true, true, true, false, true, false, false, false, true, true, true, false, true, false, true, false, true, false, true, false, false, false, false, true, false, false, false, true, false, true, true, false, false, false, true, false, false, false, true, false, false, false, false, false, false, false, true, false, false, false, false, false, false, false, false, false, false};
        // ############################################################
        

        /* Pass parts of the message to their corresponding functions */
        for (int i = 0; i < sa.length; i++){
            //System.out.println(tempz + ": " + sa[i]);
            //tempz++;
            if(i >= 0 && i <= 3){
                msgLength[a] = sa[i];
                if(a < 3)
                    a++;
            }
            else if(i >= 4 && i <= 7){
                request[b] = sa[i];
                if(b < 3)
                    b++;
            }
            else if(i >= 8 && i <= 23){
                bitmap1[c] = sa[i];
                if(c < 15)
                    c++;
            }
            else if(i >= 24 && i <= 39){
                bitmap2[d] = sa[i];
                if(d < 15)
                    d++;
            }
            else if(i >= 40 && i <= sa.length - 1){
                actualMsg[e] = sa[i];
                if(e < sa.length - 41)
                    e++;
            }
        }
        
        iMsgLength = Integer.parseInt(new String(msgLength));                   // Getting actual length of message
        strBinBitmap = hexToBinary(new String(bitmap1), new String(bitmap2));   // Getting binary string of bitmap
        binBitmap = strBinBitmap.toCharArray();
        
        if(sa[4] == '0' && sa[5] == '8' && sa[6] == '0' && sa[7] == '0'){
            char[] echoResponse = new char[sa.length];
            for(int i = 0; i < sa.length; i++){
                if(i == 6){
                    echoResponse[i] = '1';
                }
                else{
                    echoResponse[i] = sa[i];
                }
            }
            ret.put("action", "echo");
            ret.put("answer", new String(echoResponse));
            ret.put("echoLength", Integer.toString(echoResponse.length - 4));
            return ret;
        }
        
        while(f < id.length - 1 && g < actualMsg.length){
            if(binBitmap[id[f] - 1] == '1'){
                if(id[f] == 49){
                    isVar[f] = false;
                }
                h = 0;
                System.out.println(" ");
                System.out.print(id[f] + ": ");
                if(isVar[f] == true){
                    char[] hsize = new char[fLen[f]];
                    for(int j = 0; j < fLen[f]; j++){
                        if(!Character.isWhitespace(actualMsg[g]))
                           hsize[j] = actualMsg[g];
                        else{
                           hsize[j] = '0';
                           //System.out.println("null si " + g + " kaya " + hsize[j] + " na siya ngayon");
                        }
                        eValRes[f][h] = hsize[j];
                        if(isToRespond[f] == true){
                            responseLength++;
                        }
                        h++;
                        g++;
                    }
                    String shsize = new String(hsize);
                    header = Integer.parseInt(shsize);
                    for(int j = 0; j < header; j++){
                        eVal[f][j] = actualMsg[g];
                        System.out.print(eVal[f][j]); //(●￣(ｴ)￣●)
                        //System.out.print(eVal[f][j]); //(●￣(ｴ)￣●)
                        eValRes[f][h] = eVal[f][j];
                        if(isToRespond[f] == true){
                            responseLength++;
                            isToRespond[f] = false;
                        }
                        h++;
                        g++;
                    }
                }
                else if(isVar[f] == false){
                    for(int j = 0; j < fLen[f]; j++){
                        eVal[f][j] = actualMsg[g];
                        System.out.print(eVal[f][j]); //(●￣(ｴ)￣●)
                        eValRes[f][h] = eVal[f][j];
                        if(isToRespond[f] == true){
                            responseLength++;
                            isToRespond[f] = false;
                        }
                        h++;
                        g++;
                    }
                }
            }
            f++;
        }
        
        for(int i = 0; i < 57; i++){
            if(isToRespond[i] == true){
                if(id[i] == 37){
                    for(int j = 0; j < 12; j++){
                        eValRes[i][j] = '0';
                        responseLength++;
                    }
                    isToRespond[i] = false;
                }
                else if(id[i] == 39){
                    for(int j = 0; j < 2; j++){
                        eValRes[i][j] = '0';
                        responseLength++;
                    }
                    isToRespond[i] = false;
                }
                else if(id[i] == 43){
                    for(int j = 0; j < 40; j++){
                        eValRes[i][j] = ' ';
                        responseLength++;
                    }
                    isToRespond[i] = false;
                }
                else if(id[i] == 50){
                    eValRes[i][0] = eVal[49][0];
                    eValRes[i][1] = eVal[49][1];
                    eValRes[i][2] = eVal[49][2];
                    isToRespond[i] = false;
                    responseLength += 3;
                }
            }
        }
        
        responseLength += 8;
        
        if((new String(request)).equals("0200")){
            if((responseLength + 36) < 1000)
                sagot = new StringBuilder().append("0").append(Integer.toString(responseLength + 36)).append("0210").toString();
            else
                sagot = new StringBuilder().append(Integer.toString(responseLength + 36)).append("0210").toString();
        }
        else if((new String(request)).equals("0420")){
            if((responseLength + 36) < 1000)
                sagot = new StringBuilder().append("0").append(Integer.toString(responseLength + 36)).append("0430").toString();
            else
                sagot = new StringBuilder().append(Integer.toString(responseLength + 36)).append("0430").toString();
        }
        
        for(int i = 0; i < 57; i++){
            if(i == 0)
                resBinBitmap[i] = '1';
            if(isInResponse[i] == true){
                resBinBitmap[id[i] - 1] = '1';
            }
        }
        
        String[] parts = (new String(resBinBitmap)).split("-");
        String resBinBitmap1 = parts[0];
        String resBinBitmap2 = parts[1];
        
        System.out.println(resBinBitmap1 + ", " + resBinBitmap2);
        
        resBitmap1 = new java.math.BigInteger(resBinBitmap1, 2).toString(16);
        resBitmap2 = new java.math.BigInteger(resBinBitmap2, 2).toString(16);
        
        System.out.println(new java.math.BigInteger(resBinBitmap1, 2) + ", " + new java.math.BigInteger(resBinBitmap2, 2));
        
        resBitmap1 = String.format("%16s", resBitmap1).replace(" ", "0");
        resBitmap2 = String.format("%16s", resBitmap2).replace(" ", "0");
        
        sagot = new StringBuilder().append(sagot).append(resBitmap1).append(resBitmap2).toString();
        
        System.out.println(" ");
        for(int i = 0; i < 57; i++){
            if(isInResponse[i] == true){
                System.out.println(id[i] + ": " + new String(eValRes[i]).trim());
                if(id[i] == 54){
                    ret.put("partOne", sagot);
                    sagot = "";
                }
                else
                  sagot = new StringBuilder().append(sagot).append(new String(eValRes[i]).trim()).toString();
            }
        }
        
        ret.put("partTwo", sagot);
        
        if((eVal[1][0] == '0' && eVal[1][1] == '1') || (eVal[1][0] == '1' && eVal[1][1] == '0')){
            ret.put("action", "withdrawal");
            //ret.put("acctNo", new String(acctNoFormat).trim());
            ret.put("rawAcctNo", new String(eVal[46]).trim());
            ret.put("txnAmt", new String(eVal[2]).trim());
            ret.put("txnCode", new String(eVal[1]).trim());
            ret.put("mti", new String(request));
            ret.put("txnRef", new String(eVal[27]).trim());
            ret.put("acctNo", "000-001-00002-8");
            ret.put("answer", sagot);
            
            return ret;
        }
        else if(eVal[1][0] == '3' && eVal[1][1] == '0'){
            ret.put("action", "inquiry");
            ret.put("acctNo", new String(acctNoFormat).trim());
            ret.put("rawAcctNo", new String(eVal[46]).trim());
            ret.put("txnCode", new String(eVal[1]).trim());
            ret.put("mti", new String(request));
            ret.put("txnRef", new String(eVal[27]).trim());
            ret.put("answer", sagot);
            
            return ret;
        }
        else if(eVal[1][0] == '4'){
            if(eVal[1][1] == '0'){
                ret.put("action", "intraFT");
                ret.put("acctNo", new String(acctNoFormat).trim());
                ret.put("rawAcctNo", new String(eVal[46]).trim());
                ret.put("txnAmt", new String(eVal[2]).trim());
                ret.put("toAcct", new String(acctNo2Format).trim());
                ret.put("rawToAcct", new String(eVal[47]).trim());
                ret.put("txnCode", new String(eVal[1]).trim());
                ret.put("mti", new String(request));
                ret.put("txnRef", new String(eVal[27]).trim());
                
                return ret;
            }
            else if(eVal[1][1] == '4'){
                ret.put("action", "interFT");
                ret.put("acctNo", new String(acctNoFormat).trim());
                ret.put("rawAcctNo", new String(eVal[46]).trim());
                ret.put("txnAmt", new String(eVal[2]).trim());
                ret.put("toAcct", new String(acctNo2Format).trim());
                ret.put("rawToAcct", new String(eVal[47]).trim());
                ret.put("txnCode", new String(eVal[1]).trim());
                ret.put("mti", new String(request));
                ret.put("txnRef", new String(eVal[27]).trim());
                
                return ret;
            }
            else if(eVal[1][1] == '8'){
                ret.put("action", "billsPayment");
                ret.put("acctNo", new String(acctNoFormat).trim());
                ret.put("rawAcctNo", new String(eVal[46]).trim());
                ret.put("txnAmt", new String(eVal[2]).trim());
                ret.put("txnCode", new String(eVal[1]).trim());
                ret.put("mti", new String(request));
                ret.put("txnRef", new String(eVal[27]).trim());

                return ret;
            }
        }
        else if(eVal[1][0] == '9'){
            if(eVal[1][1] == '1'){
                ret.put("action", "checkbookReq");
                ret.put("acctNo", new String(acctNoFormat).trim());
                ret.put("rawAcctNo", new String(eVal[46]).trim());
                ret.put("mti", new String(request));
                ret.put("txnRef", new String(eVal[27]).trim());
                
                return ret;
            }
            else if(eVal[1][1] == '2'){
               ret.put("action", "statementReq");
               ret.put("acctNo", new String(acctNoFormat).trim());
               ret.put("rawAcctNo", new String(eVal[46]).trim());
               ret.put("mti", new String(request));
               ret.put("txnRef", new String(eVal[27]).trim());
               
               return ret;
            }
        }
        else if(eVal[1][0] == '8' && eVal[1][1] == '4'){
            ret.put("action", "billsPayment");
            ret.put("acctNo", new String(acctNoFormat).trim());
            ret.put("rawAcctNo", new String(eVal[46]).trim());
            ret.put("txnAmt", new String(eVal[2]).trim());
            ret.put("txnCode", new String(eVal[1]).trim());
            ret.put("mti", new String(request));
            ret.put("txnRef", new String(eVal[27]).trim());

            return ret;
        } 
        
    ret.put("action","error"); 
    
    return ret;
    }
}