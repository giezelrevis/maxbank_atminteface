/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atminterface;
import java.io.*;
import java.math.BigInteger;
import java.net.*;
import java.util.Iterator;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;
import java.util.Date;
/**
 *
 * @author KrabyYap
 */
public class ATMThread implements Runnable{
    private Socket server;
    private String line,input;
    ATMDatabase atmDatabase;
    ATMParser atmParser;
    private ConcurrentHashMap response;
    
    ATMThread(Socket server) {
      this.server=server;
      atmDatabase = new ATMDatabase();
      atmParser = new ATMParser();
    }
    
    public void run () {
      input = "";
      try {
        // Get input from the client
        DataInputStream in = new DataInputStream(server.getInputStream());
        PrintStream out = new PrintStream(server.getOutputStream());
        //out.println("connected");
        do{
            line = "";
            int msgLength = 0;
            InetAddress addy = server.getInetAddress();
            String sourceIp = addy.getHostAddress();
            boolean isValidMsgLength = true;
            for(int count = 3; count >= 0; count--){
                int c = in.read();
                line = line + (char)c;
                if(count == 0){
                    try{
                        msgLength = Integer.parseInt(line);
                    }catch(NumberFormatException e){
                        isValidMsgLength=false;
                    }
                }
            }
            if(isValidMsgLength){
                for(int count = 0; count < msgLength; count++) {
                  int c = in.read();
                  line = line+(char)c;
                }

                System.out.println("REQT " + (new Date()).toString() + " | IP " + sourceIp + "| Port " + server.getPort() + " | " + msgLength + " | " + line);

                String grailsOutput = "";
                response = atmParser.generateResponse(line); //parsing
                String action = (String)response.get("action");

                response.put("sourceIp", sourceIp);
                response.put("msgLength", Integer.toString(msgLength));
                response.put("msgContent", line);
                response.put("sourcePort", Integer.toString(server.getPort()));

                if(action.equals("echo")){
                    grailsOutput = atmDatabase.sendAction(response);
                    System.out.println("ECHO " + (new Date()).toString() + " | IP " + sourceIp + "| Port " + server.getPort() + " | " + (String)response.get("echoLength") + " | " + (String)response.get("answer"));
                    out.println((String)response.get("answer"));
                }
                else{
                    grailsOutput = atmDatabase.sendAction(response);//send action to 
                    String retToClient = atmParser.returnToClient(response,grailsOutput);
                    //baguhin kung ano output to atm machine
                    System.out.println(retToClient);
                    //out.println();
                    //out.print((String)response.get("answer"));
                    out.print(retToClient);
                    //out.println();
                }
            }
            else
                System.out.println("yy " + line);
        }while(!line.equals("exit"));
           
            //Print all values stored in ConcurrentHashMap instance
            /*Iterator iterator = response.keySet().iterator();
            while (iterator.hasNext()) {
                String key = iterator.next().toString();
                String value = (String)response.get(key);
                System.out.println(key + " " + value);
            }*/
        // Now close the connection
        server.close();
      } catch (IOException ioe) {
        System.out.println("IOException on socket listen: " + ioe+ " Connection was disconnected");
        //ioe.printStackTrace();
      }
    }
}
