/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atminterface;
import java.io.*;
import java.math.BigInteger;
import java.net.*;
import java.util.Iterator;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;
import java.util.Date;
import java.util.StringTokenizer;
/**
 *
 * @author KrabyYap
 */
public class ATMThread implements Runnable{
    private Socket server;
    private String line,input;
    ATMDatabase atmDatabase;
    ATMParser atmParser;
    private ConcurrentHashMap response;
    
    ATMThread(Socket server) {
      this.server=server;
      atmDatabase = new ATMDatabase();
      atmParser = new ATMParser();
    }
    
    public void run () {
      input = "";
      try {
        // Get input from the client
        DataInputStream in = new DataInputStream(server.getInputStream());
        PrintStream out = new PrintStream(server.getOutputStream());
        //out.println("connected");
        do{
            line = "";
            int msgLength = 0;
            InetAddress addy = server.getInetAddress();
            String sourceIp = addy.getHostAddress();
            String grailsOutput = "";
            boolean isValidMsgLength = true;
            Date msgTimestamp;
            String label;
            String val = null;
            
            for(int count = 3; count >= 0; count--){
                int c = in.read();
                line = line + (char)c;
                if(count == 0){
                    try{
                        msgLength = Integer.parseInt(line);
                    }catch(NumberFormatException e){
                        isValidMsgLength=false;
                    }
                }
            }
            if(isValidMsgLength){
                for(int count = 0; count < msgLength; count++) {
                  int c = in.read();
                  line = line+(char)c;
                }

                msgTimestamp = new Date();
                System.out.println("REQT " + msgTimestamp.toString() + " | IP " + sourceIp + "| Port " + server.getPort() + " | " + msgLength + " | " + line);

                response = atmParser.processRequest(line);
                response.put("sourceIp", sourceIp);
                System.out.println("RESP " + response);
                grailsOutput = atmDatabase.sendAction(response);
                
                StringTokenizer st = new StringTokenizer(grailsOutput, "{},:\""); 
                while(st.hasMoreTokens()) {
                    val = st.nextToken();
                }
                out.println(val);
                //System.out.println("response: " + response);
            }
            else
                System.out.println("yy " + line);
        }while(!line.equals("exit"));
           
            //Print all values stored in ConcurrentHashMap instance
            /*Iterator iterator = response.keySet().iterator();
            while (iterator.hasNext()) {
                String key = iterator.next().toString();
                String value = (String)response.get(key);
                System.out.println(key + " " + value);
            }*/
        // Now close the connection
        server.close();
      } catch (IOException ioe) {
        System.out.println("IOException on socket listen: " + ioe+ " Connection was disconnected");
        //ioe.printStackTrace();
      }
    }
}
