/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atminterface;

/**
 *
 * @author KrabyYap
 */
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Iterator;
public class ATMDatabase {
    private HttpURLConnection  myURLConnection;
    
    public void ATMDatabase(){
    
    }
    public String sendAction(ConcurrentHashMap inputParams){
        URL url = null;
        String action = (String)inputParams.get("request");
        
        try {
            if("Echo".equals(action)){
                url = new URL("http://localhost:8080/icbs/ATMInterfaceListener/echoTest");
            }
            if("Transaction".equals(action)){
                url = new URL("http://localhost:8080/icbs/ATMInterfaceListener/createTransaction");
            }
            
            Map<String,Object> params = new LinkedHashMap<>();
            Iterator iterator = inputParams.keySet().iterator();
            
            while (iterator.hasNext()) {
                String key = iterator.next().toString();
                String value = (String)inputParams.get(key);
                params.put(key, value);
            }
            StringBuilder postData = new StringBuilder();
            
            for (Map.Entry<String,Object> param : params.entrySet()) {
                if (postData.length() != 0) postData.append('&');
                postData.append(URLEncoder.encode(param.getKey(), "UTF-8"));
                postData.append('=');
                postData.append(URLEncoder.encode(String.valueOf(param.getValue()), "UTF-8"));
            }
            
            byte[] postDataBytes = postData.toString().getBytes("UTF-8");
            HttpURLConnection conn = (HttpURLConnection)url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
            conn.setRequestProperty("Content-Length", String.valueOf(postDataBytes.length));
            conn.setDoOutput(true);
            conn.getOutputStream().write(postDataBytes);
            Reader in = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
            String output="";
            
            for (int c; (c = in.read()) >= 0; output = output+(char)c);
            //System.out.println ("from server grails"+output);
            in.close();
            //System.out.println(output);
            return output;
        } 
        catch (MalformedURLException e) { 
            //System.out.println(e);
            // new URL() failed
            // ...
        } 
        catch (IOException e) {
            //System.out.println(e);
            // openConnection() failed
            // ...
        }  
        return "35505";
    }
}
