/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atmclient;
import java.io.*;
import java.net.*;
import java.util.*;
/**
 *
 * @author KrabyYap
 */
public class ATMClient {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String hostName = "localhost";
        int portNumber = 17000;
        String fromServer,fromUser;
    try{
        Socket kkSocket = new Socket(hostName, portNumber);
        PrintWriter out = new PrintWriter(kkSocket.getOutputStream(), true);
        BufferedReader in = new BufferedReader(
            new InputStreamReader(kkSocket.getInputStream()));
        BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in));
        do{
            System.out.print("Client: ");
            fromUser = stdIn.readLine();
            if (fromUser != null) {
                //System.out.println("Client: " + fromUser);
                out.println(fromUser);
            }
            fromServer = in.readLine();
            System.out.println("Server: " + fromServer);
            
        }while(!fromServer.equals("exit"));
    }catch(IOException e){
        System.out.println(e);
    }
        // TODO code application logic here
    }
    
}
